library(testthat)
library(occCite)

test_check("occCite")

# Setup

## Platform

|setting  |value                        |
|:--------|:----------------------------|
|version  |R version 3.3.2 (2016-10-31) |
|system   |x86_64, mingw32              |
|ui       |RStudio (1.0.136)            |
|language |(EN)                         |
|collate  |English_United States.1252   |
|tz       |America/Phoenix              |
|date     |2017-03-06                   |

## Packages

|package |*  |version |date       |source         |
|:-------|:--|:-------|:----------|:--------------|
|BIEN    |*  |1.1.0   |2017-03-07 |local (@1.1.0) |

# Check results
0 packages with problems



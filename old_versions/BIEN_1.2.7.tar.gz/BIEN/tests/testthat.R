#Tests for BIEN package

library(testthat)
library(BIEN)
test_check("BIEN")

#' @param cultivated Return cultivated records as well?  Default is FALSE.
#' @param only.new.world Return only records from the New World?  Default is true
#' @param ... Additional arguments passed to internal functions.

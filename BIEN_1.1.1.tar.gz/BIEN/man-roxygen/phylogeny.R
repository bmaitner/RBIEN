#' @param ... Additional arguments passed to internal functions.
